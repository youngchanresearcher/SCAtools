critical_data <- function(n = 50, seed = 21) {
  set.seed(seed)
  x <- stats::runif(n)
  data.frame(X = x, Y = pmin(pmax(x + stats::rnorm(n, 0, 0.1), 0), 1))
}

test_that("the critical effect size is the 1 - alpha quantile of the null", {
  fit <- suppressWarnings(sca_analysis(critical_data(), "X", "Y",
                                       ceilings = "ce_fdh", test.rep = 99,
                                       test.seed = 1))
  draws <- fit$tests$X$ce_fdh$data
  tb <- sca_table(fit)
  expect_equal(tb$effect_size_critical,
               unname(stats::quantile(draws, 0.95)))
  # The engine computes the same value for its own test plot.
  expect_equal(tb$effect_size_critical, fit$tests$X$ce_fdh$threshold.value)
  expect_identical(sca_compare(fit)$effect_size_critical,
                   tb$effect_size_critical)
})

test_that("the critical effect size follows the analysis' alpha", {
  fit <- suppressWarnings(sca_analysis(critical_data(), "X", "Y",
                                       ceilings = "ce_fdh", test.rep = 99,
                                       test.seed = 1, test.p_threshold = 0.10))
  expect_equal(sca_table(fit)$effect_size_critical,
               unname(stats::quantile(fit$tests$X$ce_fdh$data, 0.90)))
})

test_that("without a permutation test there is no critical effect size", {
  fit <- sca_analysis(critical_data(), "X", "Y", ceilings = "ce_fdh")
  expect_true("effect_size_critical" %in% names(sca_table(fit)))
  expect_true(is.na(sca_table(fit)$effect_size_critical))
})

test_that("the test plot draws the critical effect size as a dashed line", {
  fit <- suppressWarnings(sca_analysis(critical_data(), "X", "Y",
                                       ceilings = "ce_fdh", test.rep = 99,
                                       test.seed = 1))
  p <- sca_test_plot(fit)
  vlines <- Filter(function(l) inherits(l$geom, "GeomVline"), p$layers)
  dashed <- Filter(function(l) identical(l$aes_params$linetype, "dashed"),
                   vlines)
  expect_length(dashed, 1L)
  expect_equal(dashed[[1L]]$data$xintercept,
               sca_table(fit)$effect_size_critical)
})
