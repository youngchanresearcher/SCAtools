# A permutation test with too few replications, or too few observations, can
# never return a p-value at or below the threshold. Its silence then looks
# exactly like a null result, so the package says so when the test is set up.

floor_data <- function(n = 30) {
  set.seed(3)
  x <- stats::runif(n)
  data.frame(X = x, Y = pmin(pmax(x + stats::rnorm(n, 0, 0.1), 0), 1))
}

test_that("the smallest p-value follows the engine's own rule", {
  # NCA reports max((count + 1) / (R + 1), 1 / R) and caps R at n!.
  expect_equal(SCAtools:::.sca_smallest_p(19), 1 / 19)
  expect_equal(SCAtools:::.sca_smallest_p(1000, 4), 1 / 24)
  expect_equal(SCAtools:::.sca_smallest_p(1000, 30), 1 / 1000)
})

test_that("sca_analysis() warns when no test can reach the threshold", {
  expect_warning(
    sca_analysis(floor_data(), "X", "Y", ceilings = "ce_fdh",
                 test.rep = 19, test.seed = 1),
    "test.rep >= 20",
    class = "sca_test_floor"
  )
  expect_warning(
    sca_analysis(floor_data(), "X", "Y", ceilings = "ce_fdh",
                 test.rep = 19, test.p_threshold = 0.1, test.seed = 1),
    NA
  )
  expect_warning(
    sca_analysis(floor_data(), "X", "Y", ceilings = "ce_fdh", test.rep = 20,
                 test.seed = 1),
    NA
  )
  # No test, nothing to warn about.
  expect_warning(
    sca_analysis(floor_data(), "X", "Y", ceilings = "ce_fdh"),
    NA
  )
})

test_that("a sample with too few orderings is named as the cause", {
  tiny <- data.frame(X = c(0.1, 0.5, 0.9), Y = c(0.2, 0.4, 0.8))
  expect_warning(
    suppressMessages(utils::capture.output(
      sca_analysis(tiny, "X", "Y", ceilings = "ce_fdh", test.rep = 100,
                   scope = c(0, 1, 0, 1), test.seed = 1)
    )),
    "only 6 orderings",
    class = "sca_test_floor"
  )
})

test_that("sca_power() warns before a run whose power is 0 by construction", {
  expect_warning(
    sca_power(n = 30, effect = 0.2, rep = 1, test.rep = 19, test.seed = 1),
    "by construction"
  )
  expect_warning(
    sca_power(n = 30, effect = 0.2, rep = 1, test.rep = 20, test.seed = 1),
    NA
  )
})
