library(testthat)
library(SCAtools)

test_check("SCAtools")

