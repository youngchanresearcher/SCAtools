utils::globalVariables(c("x", "y", "method", "effect_size", "power",
                         ".sca_x", ".sca_line"))

